//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FAAC.rc
//
#define IDD_ENCODER                     101
#define IDD_DECODER                     102
#define IDD_ABOUT                       103
#define IDB_AUDIOCODING                 104
#define IDB_EMAIL                       106
#define IDB_MPEG4IP                     107
#define IDB_BROWSE                      108
#define IDI_ID3                         110
#define IDC_CHK_DEFAULTCFG              1000
#define IDC_CHK_DOWNMATRIX              1001
#define IDC_CHK_OLDADTS                 1002
#define IDC_CB_SAMPLERATE               1003
#define IDC_AUDIOCODING                 1004
#define IDC_CB_BITSPERSAMPLE            1004
#define IDC_EMAIL                       1005
#define IDC_MPEG4IP                     1006
#define IDC_E_BROWSE                    1007
#define IDC_BTN_BROWSE                  1008
#define IDC_RADIO_MPEG4                 1009
#define IDC_RADIO_MPEG2                 1010
#define IDC_RADIO_LOW                   1011
#define IDC_RADIO_MAIN                  1012
#define IDC_RADIO_SSR                   1013
#define IDC_RADIO_LTP                   1014
#define IDC_RADIO_RAW                   1015
#define IDC_RADIO_HE                    1016
#define IDC_BTN_BROWSE2                 1016
#define IDC_BTN_BROWSEIMPORT            1016
#define IDC_RADIO_ADTS                  1017
#define IDC_CB_BANDWIDTH                1018
#define IDC_CB_BITRATE                  1019
#define IDC_CHK_ALLOWMIDSIDE            1020
#define IDC_CHK_USETNS                  1021
#define IDC_CHK_USELFE                  1022
#define IDC_CHK_AUTOCFG                 1023
#define IDC_BTN_ABOUT                   1024
#define IDC_L_ABOUT                     1025
#define IDC_BTN_ARTFILE                 1026
#define IDC_CHK_USETNS2                 1027
#define IDC_CB_EXT                      1028
#define IDC_RADIO_BITRATE               1030
#define IDC_RADIO_QUALITY               1031
#define IDC_CB_QUALITY                  1032
#define IDC_E_ARTIST                    1034
#define IDC_CHK_TAG                     1035
#define IDC_E_TITLE                     1036
#define IDC_E_ALBUM                     1037
#define IDC_E_YEAR                      1038
#define IDC_CB_GENRE                    1039
#define IDC_E_WRITER                    1040
#define IDC_E_COMMENT                   1041
#define IDC_E_TRACK                     1042
#define IDC_E_NTRACKS                   1043
#define IDC_E_DISK                      1044
#define IDC_E_NDISKS                    1045
#define IDC_GRP_TAG                     1046
#define IDC_E_COMPILATION               1047
#define IDC_E_ARTFILE                   1048
#define IDC_BTN_LICENSE                 1049
#define IDC_CHK_COMPILATION             1050
#define IDC_GRP_DEFAULT                 1051
#define IDC_ID3                         1052
#define IDC_L_BROWSE                    1054
#define IDC_CHK_IMPORTTAG               1055
#define IDC_E_SOURCEEXT                 1056
#define IDC_E_SOURCEPATH                1057

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
