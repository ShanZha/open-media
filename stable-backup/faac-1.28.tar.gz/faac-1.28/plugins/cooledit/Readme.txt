+-----------------------------------------------------------------+
|                                                                 |
|                    Cooledit/Audition plugin                     |
|                    ------------------------                     |
|                                                                 |
+-----------------------------------------------------------------+

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.

----------------------------------------------------------------------------

FAAC is a codec plugin for Cooledit/Audition to import and export .aac/.mp4 files.

To use it:
----------

1) put FAAC and FAAD2 packages into the same folder;
2) open the project, set "Active Configuration = FAAC - win32 Release" and compile;
3) copy FAAC.flt into CoolEdit folder and delete flt.dat

To write .mp4 files:
--------------------

Select "Write .mp4" in the config dialog or
append .mp4 extension to the name of file in the "Save waveform as" dialog.

----------------------------------------------------------------------------

For suggestions, bugs report, etc., you can contact me at
ntnfrn_email-temp@yahoo.it
